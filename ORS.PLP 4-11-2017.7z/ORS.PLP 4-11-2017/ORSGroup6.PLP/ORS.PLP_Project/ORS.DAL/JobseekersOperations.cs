﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ORS.ExceptionLibrary;

namespace ORS.DAL
{
    /// <summary>
    /// Class Contains JobseekersOperations
    /// Author: ORSGroup6
    /// Date Modified: 04/07/2017
    /// Description: It contains method for different Jobseekers Operations 
    /// </summary>
    
   public class JobseekersOperations
   {
       SqlDataReader reader;
       int result;
       DataTable jsTable = new DataTable();

       /// <summary>
       /// Author: ORSGroup6
       /// Date Modified: 04/07/2017
       /// Description: Method to insert jobseeker personal details 
       /// </summary>
       
         public bool AddJobSeekerPDetails(Jobseeker js)
         {
             bool jsAdded = false;
             try
             {
                 SqlCommand cmdAdd = DataConfiguration.CreateCommand();

                 cmdAdd.CommandText = "ORSGroup6.AddJobseekers";
               
                
                 cmdAdd.Parameters.AddWithValue("@FirstName ", js.JFirstName);
                 cmdAdd.Parameters.AddWithValue("@MiddleName", js.JMiddleName);
                 cmdAdd.Parameters.AddWithValue("@LastName", js.JLastName);
                 cmdAdd.Parameters.AddWithValue("@EmailAddress", js.JEmailAddress);
                 cmdAdd.Parameters.AddWithValue("@JobSeekersAddress", js.JAddress);
                 cmdAdd.Parameters.AddWithValue("@Password", js.JPassword);
                 cmdAdd.Parameters.AddWithValue("@DOB", js.JDOB);
                 cmdAdd.Parameters.AddWithValue("@ContactNo", js.JPhoneNo);
                 cmdAdd.Parameters.AddWithValue("@Gender", js.JGender);
                 cmdAdd.Parameters.AddWithValue("@MarraigeStatus", js.JMaritalStatus);
               
                
                 cmdAdd.Connection.Open();
                 result = cmdAdd.ExecuteNonQuery();
                 cmdAdd.Connection.Close();
                

                 if (result > 0)
                     jsAdded = true;
                 
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (Exception ex)
             {
                 throw ex;
             }
             return jsAdded;
         }

         /// <summary>
         /// Author: ORSGroup6
         /// Date Modified: 04/07/2017
         /// Description: Method to insert jobseeker qualification details 
         /// </summary>
         public bool AddJobSeekerQDetails(Jobseeker jsObj)
         {
             bool jsAdded = false;
             try
             {

                 SqlCommand cmdAdd = DataConfiguration.CreateCommand();
                 cmdAdd.CommandText = "ORSGroup6.JobseekersQualificationDetail";

                 cmdAdd.Parameters.AddWithValue("@Degree", jsObj.Degree);
                 cmdAdd.Parameters.AddWithValue("@Branch", jsObj.Branch);
                 cmdAdd.Parameters.AddWithValue("@Passingyear", jsObj.PassingYr);
                 cmdAdd.Parameters.AddWithValue("@Percentage", jsObj.Percentage);
                 cmdAdd.Parameters.AddWithValue("@UniversityName", jsObj.UniversityName);
                 cmdAdd.Parameters.AddWithValue("@JobSeekerID", jsObj.JobSeekerID);
                 cmdAdd.Connection.Open();
                 result = cmdAdd.ExecuteNonQuery();
                 cmdAdd.Connection.Close();

                 if (result > 0)
                     jsAdded = true;

             }
             catch (JobseekersException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             return jsAdded;
         }

        
         /// <summary>
         /// Author: ORSGroup6
         /// Date Modified: 04/07/2017
         /// Description: Method to search jobs based on location 
         /// </summary>
         public DataTable SearchByLocation(string jobloc)
         {
             try
             {
                 SqlCommand cmdsrchloc = DataConfiguration.CreateCommand();

                 cmdsrchloc.CommandText = "ORSGroup6.SearchbyLocation";
                 cmdsrchloc.Parameters.AddWithValue("@JobLocation", jobloc);
                 cmdsrchloc.Connection.Open();
                 reader = cmdsrchloc.ExecuteReader();
                 reader.Read();
                 jsTable.Load(reader);
                 cmdsrchloc.Connection.Close(); 
             }

             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }
             return jsTable;
         }


         /// <summary>
         /// Author: ORSGroup6
         /// Date Modified: 04/07/2017
         /// Description: Method to search jobs based on designation 
         /// </summary>
         public DataTable SearchByDesignation(string jobdesig)
         {
             try
             {
                 SqlCommand cmdsrchdesig = DataConfiguration.CreateCommand();

                 cmdsrchdesig.CommandText = "ORSGroup6.SearchbyDesignation";
                 cmdsrchdesig.Parameters.AddWithValue("@Designation", jobdesig);
                 cmdsrchdesig.Connection.Open();
                 reader = cmdsrchdesig.ExecuteReader();
                 jsTable.Load(reader);
                 cmdsrchdesig.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }
             return jsTable;
         }


         /// <summary>
         /// Author: ORSGroup6
         /// Date Modified: 04/07/2017
         /// Description: Method to search jobs based on experience 
         /// </summary>
         public DataTable SearchByExperience(string jexp)
         {
             try
             {
                 SqlCommand cmdsrcexp = DataConfiguration.CreateCommand();

                 cmdsrcexp.CommandText = "ORSGroup6.SearchbyExperience";

                 cmdsrcexp.Parameters.AddWithValue("@Experience", jexp);

                 if (cmdsrcexp.Connection.State == ConnectionState.Closed)
                     cmdsrcexp.Connection.Open();
                 reader = cmdsrcexp.ExecuteReader();
                 jsTable.Load(reader);
                 cmdsrcexp.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }
             return jsTable;
         }


         /// <summary>
         /// Author: ORSGroup6
         /// Date Modified: 04/07/2017
         /// Description: Method to validate jobseeker login credentials 
         /// </summary>
        public static string ValidateLogin(Jobseeker user)
        {
            string userName = null;

            try 
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "ORSGroup6.JobSeekerVerification";

                cmd.Parameters.AddWithValue("@EmailAddress", user.JEmailAddress);
                cmd.Parameters.AddWithValue("@Password", user.JPassword);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
              
                if (dr.HasRows)
                {
                    dr.Read();
                    userName = dr[0].ToString();
                }
                cmd.Connection.Close();
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userName;
        }


        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/07/2017
        /// Description: Method to retrieve jobseeker ID 
        /// </summary>
        public static int GetJobSeekerID(Jobseeker jsuser)
        {
            int jsid=0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "ORSGroup6.GetJobSeekeID";

                cmd.Parameters.AddWithValue("@EmailAddress", jsuser.JEmailAddress);
                cmd.Parameters.AddWithValue("@Password", jsuser.JPassword);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    jsid = Convert.ToInt32(dr[0]);
                }

                cmd.Connection.Close();
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return jsid;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/07/2017
        /// Description: Method to apply jobs using jobseekerid and jobid   
        /// </summary>
         public bool ApplyJobs(Jobseeker jobj)
         {
             bool jobsApplied = false;
             try
             {
                 SqlCommand cmdAdd = DataConfiguration.CreateCommand();

                 cmdAdd.CommandText = "ORSGroup6.ApplyJobs";
                 cmdAdd.Parameters.AddWithValue("@JobId", jobj.JobID);
                 cmdAdd.Parameters.AddWithValue("@JobSeekerId", jobj.JobSeekerID);

               
                 cmdAdd.Connection.Open();
                 int result = cmdAdd.ExecuteNonQuery();
                 cmdAdd.Connection.Close();

                 if (result > 0)
                     jobsApplied = true;
             }
             catch (JobseekersException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             return jobsApplied;
         }

         /// <summary>
         /// Author: ORSGroup6
         /// Date Modified: 04/07/2017
         /// Description: Method to retrieve Applied Job details 
         /// </summary>
         public DataTable GetAppliedDetails(int jsid)
         {
             DataTable jappTable = new DataTable();
             try
             {
                 SqlCommand cmdgetjapldetails = DataConfiguration.CreateCommand();

                 cmdgetjapldetails.CommandText = "ORSGroup6.ViewAppliedJobs";
                 cmdgetjapldetails.Parameters.AddWithValue("@JobSeekerId", jsid);


                 cmdgetjapldetails.Connection.Open();
                 reader = cmdgetjapldetails.ExecuteReader();

                 jappTable.Load(reader);
             }
             catch (JobseekersException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             return jappTable;
         }

         /// <summary>
         /// Author: ORSGroup6
         /// Date Modified: 04/07/2017
         /// Description: Method to retrieve jobseeker qualification details 
         /// </summary>
         public DataTable GetQualificationDetails(int jsid)
         {
             try
             {
                 SqlCommand cmdGetqdetails = DataConfiguration.CreateCommand();

                 cmdGetqdetails.CommandText = "ORSGroup6.GetQualificationDetails";
                 cmdGetqdetails.Parameters.AddWithValue("@jobseekerid ", jsid);

                 cmdGetqdetails.Connection.Open();
                 reader = cmdGetqdetails.ExecuteReader();

                 jsTable.Load(reader);
             }
             catch (JobseekersException)
             {
                 throw;
             }
             catch (SqlException)
             {
                 throw;
             }
             catch (Exception)
             {
                 throw;
             }
             return jsTable;
         }

         /// <summary>
         /// Author: ORSGroup6
         /// Date Modified: 04/07/2017
         /// Description: Method to search jobseeker personal details 
         /// </summary>
         public static Jobseeker SearchPDetails(int jsid)
         {
             Jobseeker js = null;
             try
             {
                 SqlCommand cmd = DataConfiguration.CreateCommand();
                 cmd.CommandText = "ORSGroup6.SearchPersonalDetails";

                 cmd.Parameters.AddWithValue("@JobSeekerID", jsid);

                 cmd.Connection.Open();
                 SqlDataReader dr = cmd.ExecuteReader();
                 if (dr.HasRows)
                 {
                     dr.Read();
                     js = new Jobseeker();
                     js.JobSeekerID = Convert.ToInt32(dr["JobSeekerID"]);
                     js.JFirstName = dr["FirstName"].ToString();
                     js.JMiddleName = dr["MiddleName"].ToString();
                     js.JLastName = dr["LastName"].ToString();
                     js.JDOB = Convert.ToDateTime(dr["DOB"]);
                     js.JGender = dr["Gender"].ToString();
                     js.JPhoneNo=Convert.ToInt64(dr["ContactNo"]);
                     js.JAddress=dr["JobSeekersAddress"].ToString();
                     js.JMaritalStatus=dr["MarraigeStatus"].ToString();
                 }
                 
                 cmd.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }

             return js;
         }

         /// <summary>
         /// Author: ORSGroup6
         /// Date Modified: 04/07/2017
         /// Description: Method to search jobseeker qualification details using qualification ID
         /// </summary>
         public static Jobseeker SearchQDetailsByQID(int qid)
         {
             Jobseeker js = null;
             try
             {
                 SqlCommand cmd = DataConfiguration.CreateCommand();
                 cmd.CommandText = "ORSGroup6.SearchQDetailsByQID";

                 cmd.Parameters.AddWithValue("@qid", qid);

                 cmd.Connection.Open();
                 SqlDataReader dr = cmd.ExecuteReader();
                 if (dr.HasRows)
                 {
                     dr.Read();
                     js = new Jobseeker();
                     js.QualificationID = Convert.ToInt32(dr["QualificationID"]);
                     js.UniversityName = dr["UniversityName"].ToString();
                     js.Degree = dr["Degree"].ToString();
                     js.Branch = dr["Branch"].ToString();
                     js.PassingYr = Convert.ToInt32(dr["PassingYear"]);
                     js.Percentage=Convert.ToDouble(dr["Percentage"]);
                 }
                 cmd.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }
             return js;
         }

         /// <summary>
         /// Author: ORSGroup6
         /// Date Modified: 04/07/2017
         /// Description: Method to Insert jobseeker professional details 
         /// </summary>
         public bool AddJobSeekerPrDetails(Jobseeker jsObj)
         {
             bool jsAdded = false;
             try
             {
                 SqlCommand cmdAdd = DataConfiguration.CreateCommand();

                 cmdAdd.CommandText = "ORSGroup6.AddProfessionaDetails";
                
                 cmdAdd.Parameters.AddWithValue("@JobSeekerID", jsObj.JobSeekerID);
                 cmdAdd.Parameters.AddWithValue("@CurrentDesignation", jsObj.JCurrentDesig);
                 cmdAdd.Parameters.AddWithValue("@PrimarySkills", jsObj.JPrimarySkills);
                 cmdAdd.Parameters.AddWithValue("@SecondarySkills", jsObj.JSecondarySkills);
                 cmdAdd.Parameters.AddWithValue("@TrainingAttended", jsObj.JTrainingAttd);
                 cmdAdd.Parameters.AddWithValue("@Designation", jsObj.JDesignation);
                 cmdAdd.Parameters.AddWithValue("@Location", jsObj.DJobLocation);
                 cmdAdd.Parameters.AddWithValue("@Experience", jsObj.JExperience);

                 cmdAdd.Connection.Open();
                 result = cmdAdd.ExecuteNonQuery();
                 cmdAdd.Connection.Close();

                 if (result > 0)
                     jsAdded = true;
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (Exception ex)
             {
                 throw ex;
             }
             return jsAdded;
         }

         /// <summary>
         /// Author: ORSGroup6
         /// Date Modified: 04/07/2017
         /// Description: Method to search jobseeker professional details 
         /// </summary>
         public static Jobseeker SearchProfDetails(int jsid)
         {
             Jobseeker js = null;
             try
             {
                 SqlCommand cmd = DataConfiguration.CreateCommand();
                 cmd.CommandText = "ORSGroup6.SearchJSProfDetails";

                 cmd.Parameters.AddWithValue("@JobSeekerID", jsid);

                 cmd.Connection.Open();
                 SqlDataReader dr = cmd.ExecuteReader();
                 if (dr.HasRows)
                 {
                     dr.Read();
                     js = new Jobseeker();
                     js.JobSeekerID = Convert.ToInt32(dr["JobSeekerID"]);
                     js.JPrimarySkills = dr["PrimarySkills"].ToString();
                     js.JSecondarySkills = dr["SecondarySkills"].ToString();
                     js.JTrainingAttd = dr["TrainingAttended"].ToString();
                     js.JCurrentDesig = dr["CurrentDesignation"].ToString();
                     js.JExperience = dr["Experience"].ToString();
                     js.DJobLocation = dr["Location"].ToString();
                     js.JDesignation = dr["Designation"].ToString();
                     
                 }
                
                 cmd.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }

             return js;
         }

         /// <summary>
         /// Author: ORSGroup6
         /// Date Modified: 04/07/2017
         /// Description: Method to Update jobseeker personal details 
         /// </summary>
         public static int UpdatePdetails(Jobseeker js)
         {
             int recordsupdated = 0;

             try
             {
                 SqlCommand cmd = DataConfiguration.CreateCommand();

                 cmd.CommandText = "ORSGroup6.UpdatePersonalDetails";

                 cmd.Parameters.AddWithValue("@JobSeekerId", js.JobSeekerID);
                 cmd.Parameters.AddWithValue("@FirstName", js.JFirstName);
                 cmd.Parameters.AddWithValue("@LastName", js.JLastName);
                 cmd.Parameters.AddWithValue("@MiddleName", js.JMiddleName);
                 cmd.Parameters.AddWithValue("@ContactNo", js.JPhoneNo);
                 cmd.Parameters.AddWithValue("@Gender", js.JGender);
                 cmd.Parameters.AddWithValue("@MarraigeStatus", js.JMaritalStatus);
                 cmd.Parameters.AddWithValue("@JobSeekersAddress", js.JAddress);
                 cmd.Parameters.AddWithValue("@DOB", js.JDOB);

                 cmd.Connection.Open();
                 recordsupdated = cmd.ExecuteNonQuery();
                 cmd.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }

             return recordsupdated;
         }

         /// <summary>
         /// Author: ORSGroup6
         /// Date Modified: 04/07/2017
         /// Description: Method to Update jobseeker professional details 
         /// </summary>
         public static int UpdateProfdetails(Jobseeker js)
         {
             int recordsupdated = 0;

             try
             {
                 SqlCommand cmd = DataConfiguration.CreateCommand();

                 cmd.CommandText = "ORSGroup6.UpdateProfesionalDetails";

                 cmd.Parameters.AddWithValue("@jobseekerId", js.JobSeekerID);
                 cmd.Parameters.AddWithValue("@CurrentDesignation", js.JCurrentDesig);
                 cmd.Parameters.AddWithValue("@PrimarySkills", js.JPrimarySkills);
                 cmd.Parameters.AddWithValue("@SecondarySkills", js.JSecondarySkills);
                 cmd.Parameters.AddWithValue("@TrainingAttended", js.JTrainingAttd);
                 cmd.Parameters.AddWithValue("@Designation", js.JDesignation);
                 cmd.Parameters.AddWithValue("@Location", js.DJobLocation);
                 cmd.Parameters.AddWithValue("@Experience", js.JExperience);
                
                 cmd.Connection.Open();
                 recordsupdated = cmd.ExecuteNonQuery();
                 cmd.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }

             return recordsupdated;
         }

         /// <summary>
         /// Author: ORSGroup6
         /// Date Modified: 04/07/2017
         /// Description: Method to Update jobseeker qualification details 
         /// </summary>
         public static int UpdateQdetails(Jobseeker js)
         {
             int recordsupdated = 0;

             try
             {
                 SqlCommand cmd = DataConfiguration.CreateCommand();

                 cmd.CommandText = "ORSGROUP6.UpdateQualificationDetails";

                 cmd.Parameters.AddWithValue("@QualificationID", js.QualificationID);
                 cmd.Parameters.AddWithValue("@Degree", js.Degree);
                 cmd.Parameters.AddWithValue("@Branch", js.Branch);
                 cmd.Parameters.AddWithValue("@Percentage", js.Percentage);
                 cmd.Parameters.AddWithValue("@PassingYear", js.PassingYr);
                 cmd.Parameters.AddWithValue("@UniversityName", js.UniversityName);
                 cmd.Parameters.AddWithValue("@JobSeekerID", js.JobSeekerID);

                 cmd.Connection.Open();
                 recordsupdated = cmd.ExecuteNonQuery();
                 cmd.Connection.Close();
             }
             catch (JobseekersException ex)
             {
                 throw ex;
             }
             catch (SqlException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }

             return recordsupdated;
         }
    }
}
