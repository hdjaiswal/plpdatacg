﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.ExceptionLibrary
{
    /// <summary>
    /// Class to handle Admin exceptions
    /// Author: 
    /// Date Modified: 04/06/2017
    /// Description: Exception Class to Handle Admin Exceptions
    /// </summary>
    public class AdminException: ApplicationException
    {
        public AdminException()
            : base()
        { }
        public AdminException(string message)
            : base(message)
        { }
    }
}
