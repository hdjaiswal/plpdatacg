﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORS.ExceptionLibrary
{

    /// <summary>
    /// Class to handle Employer exceptions
    /// Author: 
    /// Date Modified: 04/06/2017
    /// Description: Exception Class to Handle Employer Exceptions
    /// </summary>
   public class EmployersException:ApplicationException
    {
       public EmployersException() :
           base()
       { }
       public EmployersException(string message) :
           base()
       { }
    }
}
