﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;

namespace ORS.BL
{
    /// <summary>
    /// Class Contains Jobseekers Validations
    /// Author: ORSGroup6
    /// Date Modified: 04/08/2017
    /// Description: It contains method for different Jobseeker's Details Validation 
    /// </summary>
   public class JobseekersValidation
    {
    JobseekersOperations jsOp = new JobseekersOperations();

    /// <summary>
    /// Author: ORSGroup6
    /// Date Modified: 04/08/2017
    /// Description: Method to validate jobseeker's personal details 
    /// </summary>
       
        public bool AddJobSeekerPDetails(Jobseeker jsObj)
        {
            bool jsAdded = false;
            try
            {
                jsAdded = jsOp.AddJobSeekerPDetails(jsObj);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsAdded;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate jobseeker's qualification details 
        /// </summary>
        public bool AddJobSeekerQDetails(Jobseeker jsObj)
        {
            bool jsAdded = false;
            try
            {
                jsAdded = jsOp.AddJobSeekerQDetails(jsObj);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsAdded;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate jobseeker's professional details 
        /// </summary>
        public bool AddJobSeekerPrDetails(Jobseeker jsObj)
        {
            bool jsAdded = false;
            try
            {
                jsAdded = jsOp.AddJobSeekerPrDetails(jsObj);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsAdded;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate Apply Jobs 
        /// </summary>
        public bool ApplyJobs(Jobseeker jobj)
        {
            bool jsApplied = false;
            try
            {
                jsApplied = jsOp.ApplyJobs(jobj);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsApplied;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate Applied Job details 
        /// </summary>
        public DataTable GetAppliedDetails(int jsid)
        {

            DataTable jappTable = new DataTable();
            try
            {
                jappTable = jsOp.GetAppliedDetails(jsid);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jappTable;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate retrieval of jobseeker's Qualification details 
        /// </summary>
        public DataTable GetQualificationDetails(int jsid)
        {
            DataTable jsTable = new DataTable();
            try
            {
                jsTable = jsOp.GetQualificationDetails(jsid);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsTable;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate  retrieval of jobseeker's Personal details
        /// </summary>
        public static Jobseeker SearchPDetails(int jsid)
        {
            Jobseeker js = null;
            try
            {
                js = JobseekersOperations.SearchPDetails(jsid);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return js;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate  retrieval of jobseeker's Professional details
        /// </summary>
        public static Jobseeker SearchProfDetails(int jsid)
        {
            Jobseeker js = null;

            try
            {
                js = JobseekersOperations.SearchProfDetails(jsid);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return js;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate  retrieval of jobseeker's Qualification details using qualification ID
        /// </summary>
        public static Jobseeker SearchQDetailsByQID(int qid)
        {
            Jobseeker js = null;

            try
            {
                js =JobseekersOperations.SearchQDetailsByQID(qid);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return js;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate  Updation of jobseeker's Personal details
        /// </summary>
        public static int UpdatePdetails(Jobseeker js)
        {
            int recordsUpdated = 0;

            try
            {
                recordsUpdated = JobseekersOperations.UpdatePdetails(js);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsUpdated;
        }


        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate  Updation of jobseeker's Professional details
        /// </summary>
        public static int UpdateProfdetails(Jobseeker js)
        {
            int recordsUpdated = 0;

            try
            {
                recordsUpdated = JobseekersOperations.UpdateProfdetails(js);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsUpdated;
        }


        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate  Updation of jobseeker's Qualification details
        /// </summary>
        public static int UpdateQdetails(Jobseeker js)
        {
            int recordsUpdated = 0;

            try
            {
                recordsUpdated = JobseekersOperations.UpdateQdetails(js);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsUpdated;
        }


        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate  Searching of job details based on location
        /// </summary>
        public DataTable SearchByLocation(string jobloc)
        {
            DataTable jsTable = new DataTable();
            try
            {
                jsTable = jsOp.SearchByLocation(jobloc);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsTable;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate  Searching of job details based on Designation
        /// </summary>
        public DataTable SearchByDesignation(string jobdesig)
        {
            DataTable jsTable = new DataTable();
            try
            {
                jsTable = jsOp.SearchByDesignation(jobdesig);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsTable;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate  Searching of job details based on Experience
        /// </summary>
        public DataTable SearchByExperience(string jexp)
        {
            DataTable jsTable = new DataTable();
            try
            {
                jsTable = jsOp.SearchByExperience(jexp);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return jsTable;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate Validation of Login Credentials
        /// </summary>
        public static string ValidateLogin(Jobseeker user)
        {
            string userName = null;

            try
            {
                userName = JobseekersOperations.ValidateLogin(user);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userName;
        }

        /// <summary>
        /// Author: ORSGroup6
        /// Date Modified: 04/08/2017
        /// Description: Method to validate retrieval of Jobseeker ID
        /// </summary>
        public static int GetJobSeekerID(Jobseeker jsuser)
        {
            int jsid =0;

            try
            {
                jsid = JobseekersOperations.GetJobSeekerID(jsuser);
            }
            catch (JobseekersException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

           return jsid;
        }
    }
}
