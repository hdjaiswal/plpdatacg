﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;


namespace WebApplication2
{
    /// <summary>
    /// Class consists of Login credentials
    /// Author: ORSGroup6
    /// Date Modified: 04/09/2017
    /// Description: It consists of Login Page
    /// </summary>
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                Jobseeker jsuser = new Jobseeker();

                AdminEntity adminuser = new AdminEntity();

                Employer empuser = new Employer();

                if (ddlUserType.Text == "Admin")
                {
                    adminuser.Username = txtUser.Text;
                    adminuser.Password = txtPassword.Text;
                    string adminusername = AdminValidations.ValidateAdmin(adminuser);
                    if (adminusername != null)
                    {
                        Session["user"] = adminusername;
                        Response.Redirect("Admin.aspx");
                    }
                    else
                    {
                        Response.Write("<script>alert('Invalid Username or Password');</script>");
                    }
                }
                else
                    if (ddlUserType.Text == "Job Seeker")
                    {
                        jsuser.JEmailAddress = txtUser.Text;
                        jsuser.JPassword = txtPassword.Text;
                        string jsemail = JobseekersValidation.ValidateLogin(jsuser);
                        if (jsemail != null)
                        {
                            int jsid = JobseekersValidation.GetJobSeekerID(jsuser);
                            Session["user"] = jsemail;
                            Session["jsid"] = jsid;
                            Response.Redirect("PersonalDetails.aspx");
                        }
                        else
                        {
                            Response.Write("<script>alert('Invalid Username or Password');</script>");
                        }
                    }
                    else
                        if (ddlUserType.Text == "Employer")
                        {
                            empuser.EEmailAddress = txtUser.Text;
                            empuser.EPassword = txtPassword.Text;
                            string empemail = EmployersValidation.ValidateUser(empuser);
                            if (empemail != null)
                            {
                                int empid = EmployersValidation.GetEmployeeID(empuser);
                                Session["user"] = empemail;
                                Session["empid"] = empid;
                                Response.Redirect("PostNewJobs.aspx");
                            }
                            else
                            {
                                Response.Write("<script>alert('Invalid Username or Password');</script>");
                            }
                        }
                        else
                        {
                            Response.Write("<script>alert('Invalid Credentials');</script>");
                        }
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (EmployersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            finally
            {
                txtUser.Text = "";
                txtPassword.Text="";
                ddlUserType.SelectedIndex=0;
                txtUser.Focus();
            }
        }
    }
}