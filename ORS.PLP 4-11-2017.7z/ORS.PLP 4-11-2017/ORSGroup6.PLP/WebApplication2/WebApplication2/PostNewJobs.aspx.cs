﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;

namespace WebApplication2
{
    /// <summary>
    /// Class consists of post jobs by Employee 
    /// Author: ORSGroup6
    /// Date Modified: 04/09/2017
    /// Description: It consists of jobs Posted by Employee Page 
    /// </summary>
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

             lbluser.Text = "Welcome " + Session["user"];
             lblempid.Text = "Your ID " + Session["empid"];
             Master.LogoutVisible = true;
            
        }

        EmployersValidation validationObj = new EmployersValidation();
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Employer empObj = new Employer();
                int empid = Convert.ToInt32(Session["empid"]);
                    empObj.EmployeeID = empid;
                empObj.DCompanyName = txtCName.Text; ;
                empObj.DPost = txtPost.Text;
                empObj.DVacancies = Convert.ToInt32(txtTvacancies.Text);
                empObj.DPostedDate = Convert.ToDateTime(txtpostdate.Text);
                empObj.DLastDate = Convert.ToDateTime(txtlastdate.Text);
                empObj.DDescription = txtDes.Text;
                empObj.DPackage = Convert.ToDouble(txtPackage.Text);
                empObj.DJobLocation = txtJobLocatn.Text;
                empObj.DExperience = dllExp.Text;
              
                validationObj.AddJobs(empObj);
                Response.Write("<script>alert('Job Posted Successfully')</script>");
            }
            catch (EmployersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            finally
            {
                txtCName.Text = "";
                txtDes.Text = "";
                txtJobLocatn.Text="";
                txtlastdate.Text = "";
                txtPackage.Text = "";
                txtPost.Text = "";
                txtpostdate.Text = "";
                txtTvacancies.Text = "";
                txtCName.Focus();
            }
        }
    }
}