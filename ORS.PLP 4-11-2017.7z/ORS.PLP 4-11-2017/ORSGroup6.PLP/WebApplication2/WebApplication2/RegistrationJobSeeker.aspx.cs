﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;

namespace WebApplication2
{
    /// <summary>
    /// Class Contains Jobseeker Registration
    /// Author: ORSGroup6
    /// Date Modified: 04/09/2017
    /// Description: It contains events for Jobseeker registration Page
    /// </summary>
    public partial class RegistrationJobSeeker : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        JobseekersValidation validationObj = new JobseekersValidation();

        protected void btnJsReg_Click(object sender, EventArgs e)
        {
            try
            {
                Jobseeker jsObj = new Jobseeker();

                jsObj.JFirstName = txtJSFName.Text;
                jsObj.JMiddleName = txtJSMName.Text;
                jsObj.JLastName = txtJSLName.Text;
                jsObj.JEmailAddress = txtJSEmailAdd.Text;
                jsObj.JDOB = Convert.ToDateTime(txtjsdob.Text);
                jsObj.JGender=ddlgender.Text;
                jsObj.JMaritalStatus = ddlmarital.Text;
                jsObj.JPassword = txtPass.Text;
                jsObj.JPhoneNo = Convert.ToInt64(txtJSContact.Text);
                jsObj.JAddress = txtAddress.Text;

                validationObj.AddJobSeekerPDetails(jsObj);
                Response.Write("<script>alert('Registered Successfully, Please Login')</script>");
                Response.Redirect("LoginPage.aspx");
              
            }

            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}