﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;

namespace WebApplication2
{
    /// <summary>
    /// Class consists of Applied Jobs page
    /// Author: ORSGroup6
    /// Date Modified: 04/09/2017
    /// Description: It consists of Applied Jobs page
    /// </summary>
    public partial class AppliedJobs : System.Web.UI.Page
    {

        JobseekersValidation validationObj = new JobseekersValidation();

        protected void Page_Load(object sender, EventArgs e)
        {
           try
           {
                lblUser.Text = "Welcome " + Session["user"];
                lbljsid.Text = "Your ID :" + Session["jsid"];
                Master.LogoutVisible = true;

                DataTable jobTable = new DataTable();
                int jsid = Convert.ToInt32(Session["jsid"]);
                jobTable = validationObj.GetAppliedDetails(jsid);
               if(jobTable.Rows.Count>0)
               {
                grdappliedjobs.DataSource = jobTable;
                grdappliedjobs.DataBind();
               }
           
               else
                    Response.Write("<script>alert('Data is not available')</script>");
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
           
        }
    }
}