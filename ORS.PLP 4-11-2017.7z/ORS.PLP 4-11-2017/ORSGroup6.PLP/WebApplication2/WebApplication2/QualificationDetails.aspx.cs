﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;

namespace WebApplication2
{
    /// <summary>
    /// Class Contains jobseeker's qualification details
    /// Author: ORSGroup6
    /// Date Modified: 04/09/2017
    /// Description: It contains events for jobseeker's qualification details page
    /// </summary>
    public partial class QualificationDetails1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblUser.Text = "Welcome " + Session["user"];
            lbljsid.Text = "Your ID :" + Session["jsid"];
            Master.LogoutVisible = true;
            
        }

        JobseekersValidation validationObj = new JobseekersValidation();

        protected void btnSave_Click(object sender, EventArgs e)
        {
            Jobseeker jsObj = new Jobseeker();
            DataTable jsTable = new DataTable();
            try
            {
                int jsid = Convert.ToInt32(Session["jsid"]);
                jsObj.JobSeekerID = jsid;
                jsObj.PassingYr = Convert.ToInt32(txtPassingYr.Text);
                jsObj.Percentage = Convert.ToDouble(txtPercentage.Text);
                jsObj.UniversityName = txtUName.Text;
                jsObj.Degree = dllDegree.Text;
                jsObj.Branch = txtBranch.Text;

                validationObj.AddJobSeekerQDetails(jsObj);
                Response.Write("<script>alert('Qualification Details are saved successfully')</script>");
                jsTable = validationObj.GetQualificationDetails(jsid);

                gvqdetails.DataSource = jsTable;
                gvqdetails.DataBind();
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
          
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            finally
            {
                txtUName.Text = "";
                txtPassingYr.Text = "";
                txtPercentage.Text = "";
                txtBranch.Text = "";
                dllDegree.SelectedIndex = 0;
                dllDegree.Focus();  
            }
        }

        protected void btnShow_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable jsTable = new DataTable();
                int jsid = Convert.ToInt32(Session["jsid"]);
                jsTable = validationObj.GetQualificationDetails(jsid);

                gvqdetails.DataSource = jsTable;
                gvqdetails.DataBind();
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnsrch_Click(object sender, EventArgs e)
        {
            try
            {
                int qid = Convert.ToInt32(txtqid.Text);
                Jobseeker js = JobseekersValidation.SearchQDetailsByQID(qid);
                if (js != null)
                {
                   txtUName.Text = js.UniversityName;
                    txtBranch.Text = js.Branch;
                    txtPassingYr.Text = Convert.ToString(js.PassingYr);
                    dllDegree.SelectedItem.Text = js.Degree;
                    txtPercentage.Text=Convert.ToString(js.Percentage);
                }
                else
                {
                    Response.Write("<script>alert('Qualification ID not found')</script>");
                }
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
          
           
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            Jobseeker jsObj = new Jobseeker();

            DataTable jsTable = new DataTable();
            try
            {
                int jsid = Convert.ToInt32(Session["jsid"]);
                jsObj.QualificationID = Convert.ToInt32(txtqid.Text);
                jsObj.JobSeekerID = jsid;
                jsObj.PassingYr = Convert.ToInt32(txtPassingYr.Text);
                jsObj.Percentage = Convert.ToDouble(txtPercentage.Text);
                jsObj.UniversityName = txtUName.Text;
                jsObj.Degree = dllDegree.Text;
                jsObj.Branch = txtBranch.Text;
               

                JobseekersValidation.UpdateQdetails(jsObj);
                Response.Write("<script>alert('Qualification Details Updated successfully')</script>");
                jsTable = validationObj.GetQualificationDetails(jsid);

                gvqdetails.DataSource = jsTable;
                gvqdetails.DataBind();
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            finally
            {
                txtUName.Text = "";
                txtPassingYr.Text = "";
                txtPercentage.Text = "";
                txtBranch.Text = "";
                dllDegree.SelectedIndex=0;
                dllDegree.Focus();
            }
        }
    }
}