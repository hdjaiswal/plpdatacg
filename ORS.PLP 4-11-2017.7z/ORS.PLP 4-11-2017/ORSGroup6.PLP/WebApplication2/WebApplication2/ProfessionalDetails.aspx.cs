﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;

namespace WebApplication2
{
    /// <summary>
    /// Class Contains jobseeker's professional details
    /// Author: ORSGroup6
    /// Date Modified: 04/09/2017
    /// Description: It contains events for jobseeker's professional details Page
    /// </summary>
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            lblUser.Text = "Welcome " + Session["user"];
            lbljsid.Text = "Your ID :" + Session["jsid"];
            Master.LogoutVisible = true;
         
        }

        JobseekersValidation validationObj = new JobseekersValidation();
        protected void btnPDSubmit_Click(object sender, EventArgs e)
        {
            Jobseeker jsObj=new Jobseeker();
            try
            {
                jsObj.JobSeekerID = Convert.ToInt32(Session["jsid"]);
                jsObj.JCurrentDesig = txtCDesig.Text;
                jsObj.JPrimarySkills = txtPrimerySkills.Text;
                jsObj.JSecondarySkills = txtSecondarySkills.Text;
                jsObj.JTrainingAttd = txtCertification.Text;
                jsObj.JDesignation = txtPostApplied.Text;
                jsObj.DJobLocation = txtDesLocation.Text;
                jsObj.JExperience = dllExp.Text;

                validationObj.AddJobSeekerPrDetails(jsObj);
                Response.Write("<script>alert('Professional Details are saved successfully')</script>");
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            finally
            {
                txtCDesig.Text = "";
                txtCertification.Text = "";
                txtDesLocation.Text = "";
                txtPostApplied.Text = "";
                txtPrimerySkills.Text = "";
                txtSecondarySkills.Text = "";
                dllExp.SelectedIndex = 0;
                txtPrimerySkills.Focus();
            }
        }

        protected void btnedit_Click(object sender, EventArgs e)
        {
            try
            {
                int jsid = Convert.ToInt32(Session["jsid"]);
                Jobseeker js = JobseekersValidation.SearchProfDetails(jsid);
                if (js != null)
                {
                    txtPrimerySkills.Text = js.JPrimarySkills;
                    txtSecondarySkills.Text = js.JSecondarySkills;
                    txtCertification.Text = js.JTrainingAttd;
                    dllExp.SelectedItem.Text = js.JExperience;
                    txtCDesig.Text = js.JCurrentDesig;
                    txtDesLocation.Text=js.DJobLocation;
                    txtPostApplied.Text=js.JDesignation;
                }
                else
                {
                    string message = "JobSeeker ID not found : " + jsid;
                    throw new JobseekersException(message);
                }
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            Jobseeker updateObj = new Jobseeker();
            try
            {
                updateObj.JobSeekerID = Convert.ToInt32(Session["jsid"]);
                updateObj.JCurrentDesig = txtCDesig.Text;
                updateObj.JPrimarySkills = txtPrimerySkills.Text;
                updateObj.JSecondarySkills = txtSecondarySkills.Text;
                updateObj.JTrainingAttd = txtCertification.Text;
                updateObj.JDesignation = txtPostApplied.Text;
                updateObj.DJobLocation = txtDesLocation.Text;
                updateObj.JExperience = dllExp.Text;

                JobseekersValidation.UpdateProfdetails(updateObj);
                Response.Write("<script>alert('Professional Details updated successfully')</script>");
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            finally
            {
                txtCDesig.Text = "";
                txtCertification.Text = "";
                txtDesLocation.Text = "";
                txtPostApplied.Text = "";
                txtPrimerySkills.Text = "";
                txtSecondarySkills.Text = "";
                dllExp.SelectedIndex = 0;
                txtPrimerySkills.Focus();
            }
        }
    }
}