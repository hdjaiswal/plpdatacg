﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ORS.BL;
using ORS.DAL;
using ORS.Entity;
using ORS.ExceptionLibrary;
using System.Data;


namespace WebApplication2
{
    /// <summary>
    /// Class Contains jobseeker's personal details
    /// Author: ORSGroup6
    /// Date Modified: 04/09/2017
    /// Description: It contains events for jobseeker's personal details page.
    /// </summary>
    public partial class PersonalDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            lblUser.Text = "Welcome " + Session["user"];
            lbljsid.Text = "Your ID :" + Session["jsid"];

            Master.LogoutVisible = true;
            if (!IsPostBack)
            {
                try
                {
                    int jsid = Convert.ToInt32(Session["jsid"]);
                    Jobseeker js = JobseekersValidation.SearchPDetails(jsid);
                    if (js != null)
                    {
                        txtAddress.Text = js.JAddress;
                        txtDOB.Text = js.JDOB.ToString();
                        txtJSContact.Text = js.JPhoneNo.ToString();
                        ddlistgender.SelectedItem.Text = js.JGender.ToString(); ;
                        ddlmarital.SelectedItem.Text = js.JMaritalStatus.ToString();
                        txtJSFName.Text = js.JFirstName.ToString(); ;
                        txtJSLName.Text = js.JLastName.ToString();
                        txtJSMName.Text = js.JMiddleName.ToString();
                    }
                    else
                    {
                        string message = "JobSeekers ID not found : " + jsid;
                        throw new JobseekersException(message);
                    }
                }
                catch (JobseekersException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
                catch (SystemException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
            }
        }
            
        JobseekersValidation validationObj = new JobseekersValidation();

        protected void btnUpdatePd_Click(object sender, EventArgs e)
        {
            Jobseeker updateObj = new Jobseeker();
            try
            {
                int jsid = Convert.ToInt32(Session["jsid"]);
                updateObj.JobSeekerID = jsid;
                updateObj.JFirstName = txtJSFName.Text;
                updateObj.JMiddleName = txtJSMName.Text;
                updateObj.JLastName = txtJSLName.Text;
                updateObj.JDOB = Convert.ToDateTime(txtDOB.Text);
                updateObj.JGender = ddlistgender.Text;
                updateObj.JMaritalStatus = ddlmarital.Text;
                updateObj.JPhoneNo = Convert.ToInt64(txtJSContact.Text);
                updateObj.JAddress = txtAddress.Text;

                JobseekersValidation.UpdatePdetails(updateObj);
                Response.Write("<script>alert('Personal Details updated Successfully')</script>");    
            }
            catch (JobseekersException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}