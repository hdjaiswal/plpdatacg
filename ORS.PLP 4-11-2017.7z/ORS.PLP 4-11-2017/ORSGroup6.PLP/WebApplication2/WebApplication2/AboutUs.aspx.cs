﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    /// <summary>
    /// Class consists of AboutUs's page
    /// Author: ORSGroup6
    /// Date Modified: 04/09/2017
    /// Description: It consists of AboutUs's page
    /// </summary>
    public partial class WebForm5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}