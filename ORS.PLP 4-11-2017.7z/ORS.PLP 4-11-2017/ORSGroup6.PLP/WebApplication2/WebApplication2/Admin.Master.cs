﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    /// <summary>
    /// Class consists of Admin's master page
    /// Author: ORSGroup6
    /// Date Modified: 04/09/2017
    /// Description: It consists of Admin's master page
    /// </summary>
    public partial class Admin1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public bool LogoutVisible
        {
            get { return lbtnLogout.Visible; }
            set
            { lbtnLogout.Visible = value; }
        }
        protected void lbtnLogout_Click1(object sender, EventArgs e)
        {
            Session["user"] = null;
            Response.Redirect("LoginPage.aspx");
        }
    }
}