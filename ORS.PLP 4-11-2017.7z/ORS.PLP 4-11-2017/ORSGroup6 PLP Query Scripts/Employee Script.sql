--Schema Creation

Create Schema ORSGroup6 

-- Employee Login Table 

Create Table ORSGroup6.EmployeersLogin
(
LoginID int identity(1,1),
EmailAddress varchar(20) UNIQUE,
Password varchar(20),
EmployeeID int 
)

select * from ORSGroup6.EmployeersLogin

select * from ORSGroup6.EmployeeDetails

--Employee Details Table 

Create Table ORSGroup6.EmployeeDetails
(
EmployeeID int identity(1,1) Primary key,
FirstName varchar(20),
LastName varchar(20),
CompanyNAme varchar(20),
Designation varchar(20),
Location varchar(20),
ContactNO bigint,
EmailAddress varchar(20)Unique
)

-- Procedure to Add New Employee Details 

Create Procedure ORSGroup6.AddEmployee
(
@FirstName varchar(20),
@LastName varchar(20),
@Companyname varchar(20),
@Designation varchar(20),
@Location varchar(20),
@ContactNO bigint,
@EmailAddress varchar(20),
@Password varchar(20))
AS
BEGIN
insert into ORSGroup6.EmployeeDetails Values(@FirstName,@LastName,@CompanyName,@Designation,@Location,@ContactNO,@EmailAddress)
Insert into ORSGroup6.EmployeersLogin Values(@EmailAddress,@Password,scope_identity())
END

EXEC ORSGroup6.AddEmployee 'Riya','Sharma','Syntel','ER','Mumbai',78965458957,'riya@gmail.com','raj@123'

select * from ORSGroup6.EmployeeDetails

select * from ORSGroup6.EmployeersLogin

--Procedure to Verify Employee Credentials

Alter Procedure ORSGroup6.EmployeeVerification
 (     @EmailAddress NVARCHAR(20),
      @Password NVARCHAR(20)
)
AS
BEGIN
Select EmailAddress,EmployeeID from ORSGroup6.EmployeersLogin where EmailAddress=@EmailAddress AND Password=@Password
END

EXEC ORSGroup6.EmployeeVerification 'riya@gmail.com','raj@123'

--Procedure to get Employee ID

Create Procedure ORSGroup6.GetEmployeeID
 (     @EmailAddress NVARCHAR(20),
      @Password NVARCHAR(20)
)
AS
BEGIN
Select EmployeeID from ORSGroup6.EmployeersLogin where EmailAddress=@EmailAddress AND Password=@Password
END

EXEC ORSGroup6.GetEmployeeID 'riya@gmail.com','raj@123'




 



