
--Jobseekers Login Table

create table ORSGroup6.JobseekersLogin
(
LoginID int identity(1,1) PRIMARY KEY,
EmailAddress varchar(50)UNIQUE,
Password varchar(20),
jobseekerID int 
)

--Jobseekers Personal Details Table

 create table  ORSGroup6.JobseekersPersonalDetails
 (
JobSeekerID int identity(1,1) PRIMARY KEY,
FirstName Varchar(20),
LastName Varchar(20),
MiddleName varchar(20),
ContactNo bigint,
EmailAddress varchar(50)UNIQUE,
Gender varchar(10),
MarraigeStatus varchar(10),
JobSeekersAddress varchar(50),
DOB DateTime
 ) 

 -- Jobseekers Qualification Details Table 

 Create Table  ORSGroup6.JobseekersQualificationDetails 
 (
 QualificationID int identity(1,1) Primary key,
 Degree Varchar(20),
 Branch Varchar(20),
 Passingyear int,
 Percentage Decimal,
 UniversityName varchar(20),
 JobseekersID int Foreign key references ORSGroup6.JobseekersPersonalDetails(jobseekerID)
 )

 ALTER TABLE ORSGroup6.JobseekersQualificationDetails
ALTER COLUMN  Percentage float(2);

truncate table ORSGroup6.JobseekersQualificationDetails

 --Jobseekers Professional Details Table

 Create Table ORSGroup6.JobSeekerProfessionalDetails
 (
JobSeekerID int Foreign key references ORSGroup6.JobseekersPersonalDetails(jobseekerID) Unique,
CurrentDesignation varchar(20),
PrimarySkills varchar(50),
SecondarySkills varchar(50),
TrainingAttended varchar(30),
Designation varchar(20),
Location varchar(30),
Experience varchar(20),
 )

--Procedure to Insert Jobseekers Personal Details into Jobseekers Personal Details Table

Alter Procedure ORSGroup6.AddJobseekers
(
@FirstName Varchar(20),
@LastName Varchar(20),
@MiddleName varchar(20),
@ContactNo bigint,
@EmailAddress varchar(50),
@Gender varchar(10),
@MarraigeStatus varchar(10),
@JobSeekersAddress varchar(50),
@DOB DateTime,
@Password varchar(20)
)
AS
BEGIN
SET NOCOUNT ON;
insert into ORSGroup6.JobseekersPersonalDetails Values(@FirstName,@LastName,@MiddleName,@ContactNO,@EmailAddress,@Gender,@MarraigeStatus,@JobSeekersAddress,@DOB)
Insert into ORSGroup6.JobseekersLogin Values(@EmailAddress,@Password,scope_identity())
END
select JobSeekerID from ORSGroup6.JobseekersPersonalDetails

EXEC ORSGroup6.AddJobseekers 'ramesh.rao@gmail.com','hitna123','Ramesh','Patil','Rao',7896548596,'male','single','Delhi','02/02/1964','Manager','java','ADO.net','SPEAKING','DEVELOPER','Mumbai','2-3'
 
select * from  ORSGroup6.JobseekersPersonalDetails

select * from ORSGroup6.JobseekersLogin 

--Procedure for Jobseeker Verification

 Alter Procedure ORSGroup6.JobSeekerVerification
 (     @EmailAddress NVARCHAR(20),
      @Password NVARCHAR(20)
)
AS
BEGIN
      SELECT EmailAddress
      FROM ORSGroup6.JobseekersLogin WHERE EmailAddress = @EmailAddress AND Password = @Password   
END

select * from ORSGroup6.JobseekersLogin;

Exec ORSGroup6.JobSeekerVerification 'c@gmail.com','hitna123';

--Procedure to get Jobseeker ID

Create Procedure ORSGroup6.GetJobSeekeID
 (     @EmailAddress NVARCHAR(20),
      @Password NVARCHAR(20)
)
AS
BEGIN
      
      SELECT JobSeekerID
      FROM ORSGroup6.JobseekersLogin WHERE EmailAddress = @EmailAddress AND Password = @Password   
END

exec ORSGroup6.GetJobSeekeID 'c@gmail.com','hitna123';

-- Procedure to Add Jobseekers Qualification Details 

Alter Procedure ORSGroup6.JobseekersQualificationDetail
(
 @Degree Varchar(20),
 @Branch Varchar(20),
 @Passingyear int,
 @Percentage float(2),
 @UniversityName varchar(20),
 @JobSeekerID int
 )
AS 
Begin
SET NOCOUNT ON;
BEGIN
Insert into ORSGroup6.JobseekersQualificationDetails Values(@Degree,@Branch,@Passingyear,@Percentage,@UniversityName,@JobSeekerID)
END
END

--Procedure to retrieve Qualification Details

Alter Proc ORSGroup6.GetQualificationDetails
(
@jobseekerid int
)
AS
BEGIN
Select QualificationID,Degree,Branch,PassingYear,Percentage,UniversityName from ORSGroup6.JobseekersQualificationDetails where JobseekersID=@jobseekerid;
END

--Procedure to retrieve Personal Details

CREATE PROC ORSGroup6.SearchPersonalDetails
(
	@JobSeekerID	INT
)
AS
BEGIN
	SELECT * FROM ORSGroup6.JobseekersPersonalDetails WHERE JobseekerID = @JobSeekerID
END

--Procedure to retrieve Qualification Details by QualificationID
  
Alter Proc ORSGroup6.SearchQDetailsByQID
(
@qid int
)
AS
BEGIN
Select QualificationID,Degree,Branch,PassingYear,Percentage,UniversityName from ORSGroup6.JobseekersQualificationDetails where QualificationID=@qid;
END

--Procedure to add Jobseekers Professional Details 

Alter Procedure ORSGroup6.AddProfessionaDetails
(
@jobseekerId int,
@CurrentDesignation varchar(20),
@PrimarySkills varchar(50),
@SecondarySkills varchar(50),
@TrainingAttended varchar(30),
@Designation varchar(20),
@Location varchar(30),
@Experience varchar(20)
)
AS 
BEGIN
Insert into ORSGroup6.JobSeekerProfessionalDetails Values(@jobseekerId,@CurrentDesignation,@PrimarySkills,@SecondarySkills,@TrainingAttended,@Designation,@Location,@Experience)
END 

--Procedure to retrieve Jobseekers Professional Details

CREATE PROC ORSGroup6.SearchJSProfDetails
(
	@JobSeekerID	INT
)
AS
BEGIN
	SELECT * FROM ORSGroup6.JobSeekerProfessionalDetails WHERE JobseekerID = @JobSeekerID
END


--Procedure To Update Jobseekers Personal Details

Alter Procedure ORSGroup6.UpdatePersonalDetails 
(
@JobSeekerId int,
@FirstName Varchar(20),
@LastName Varchar(20),
@MiddleName varchar(20),
@ContactNo bigint,
@Gender varchar(10),
@MarraigeStatus varchar(10),
@JobSeekersAddress varchar(50),
@DOB Datetime)
AS 
UPDATE ORSGroup6.JobseekersPersonalDetails
SET
FirstName=@FirstName ,
LastName=@LastName ,
MiddleName=@MiddleName ,
ContactNo=@ContactNo,
Gender= @Gender ,
MarraigeStatus=@MarraigeStatus,
JobSeekersAddress=@JobSeekersAddress,
DOB=@DOB
Where JobSeekerID=@JobSeekerId

Exec ORSGroup6.JobseekersPersonalDetails 1,'pranita','Shete','rajesh',1236547896,'Female','Married','mumbai','06/24/1999'

-- Procedure to Update Jobseekers Professional Details
 
Alter Procedure UpdateProfesionalDetails
(
@jobseekerId int,
@CurrentDesignation varchar(20),
@PrimarySkills varchar(50),
@SecondarySkills varchar(50),
@TrainingAttended varchar(30),
@Designation varchar(20),
@Location varchar(30),
@Experience varchar(20))
As
UPDATE ORSGroup6.JobSeekerProfessionalDetails
SET 
CurrentDesignation=@CurrentDesignation,
PrimarySkills=@PrimarySkills,
SecondarySkills=@SecondarySkills,
TrainingAttended=@TrainingAttended,
Designation=@Designation,
Location=@Location,
Experience=@Experience
where JobSeekerID= @jobseekerId;

--Procedure to Update Qualification Details

Alter Procedure ORSGROUP6.UpdateQualificationDetails 
(
@QualificationID int,
@Degree Varchar(20),
@Branch Varchar(20),
@Percentage float(2),
@PassingYear int,
@UniversityName varchar(20),
@JobSeekerID int
)
AS 
UPDATE ORSGroup6.JobseekersQualificationDetails
SET
Degree=@Degree ,
Branch=@Branch ,
PassingYear=@PassingYear ,
Percentage=@Percentage,
UniversityName= @UniversityName
Where QualificationID=@QualificationID AND JobSeekersID=@JobSeekerID

exec ORSGROUP6.UpdateQualificationDetails  6,'BTECH','CSE',2015,82,'Pune',1;
