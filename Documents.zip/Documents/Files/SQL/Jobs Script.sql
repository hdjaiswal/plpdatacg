

--Job Details Table

Create table ORSGroup6.JobDetails
(
	JobId int identity(1,1) Primary Key,
	CompanyName varchar(20) ,
	Post varchar(20),
	Vacancies int,
	PostedDate datetime,
	LastDate datetime,
	CompanyDescription nvarchar(2000),
	Package Decimal(2,2),
	JobLocation varchar(20),
	Experience varchar(20),
	EmployeeID int Foreign key references ORSGroup6.EmployeeDetails(EmployeeID),
	)

	drop table ORSGroup6.JobDetails

	alter table  ORSGroup6.JobDetails 
	alter column Package float(2);

select * from ORSGroup6.JobDetails

select * from ORSGroup6.AppliedJobs

--AppliedJob Details Table

Create table ORSGroup6.AppliedJobs
(
	JobAppliedId int identity(1,1) Primary key,
	JobId int Foreign key references ORSGroup6.JobDetails(JobId),
	EmployeeId  int ,
	JobSeekerId  int Foreign key references ORSGroup6.JobseekersPersonalDetails(JobSeekerID),
	)

	

--Procedure to Insert Job Details in Job Details Table

Alter Procedure ORSGroup6.AddJobs
(
@CompanyName varchar(20) ,
@Post varchar(20),
@Vacancies int,
@PostedDate datetime,
@LastDate datetime,
@CompanyDescription nvarchar(2000),
@Package float(2),
@JobLocation varchar(20),
@Experience varchar(20),
@EmployeeID int
)
AS
BEGIN
Insert into ORSGroup6.JobDetails Values(@CompanyName,@Post,@Vacancies,@PostedDate,@LastDate,@CompanyDescription,@Package,@JobLocation,@Experience,@EmployeeID);
END


select * from ORSGroup6.JobDetails;

EXEC ORSGroup6.AddJobs 'Syntel','manager',3,'02/02/2010','03/03/2016','greatcomapnny',20.02,'mumbai','2-3',1

Select * from ORSGroup6.JobDetails 

select * from ORSGroup6.AppliedJobs

--Procedure to Apply Jobs

Create Procedure ORSGroup6.ApplyJobs
(
@JobId int,
@JobSeekerId int
)
AS 
BEGIN
Declare @EmployeeId int
SET @EmployeeID =(Select EmployeeID From ORSGroup6.JobDetails  where JobId=@JobId )
Insert into ORSGroup6.AppliedJobs values(@JobId,@EmployeeId,@JobSeekerId)
END

EXEC ORSGroup6.ApplyJobs 1,1


--Procedure to view Posted Jobs by Employee

Create Procedure ORSGroup6.ViewjobsByEmployee
(
@EmployeeID int
)
AS 
BEGIN 
SELECT  * FROM  ORSGroup6.JobDetails where(EmployeeID=@EmployeeID)
END 

EXEC ORSGroup6.ViewjobsByEmployee 1


--Procedure to view those JobSeekers Details to Employee who have applied jobs posted by Employee 

Create PROCEDURE ORSGroup6.viewsJobseekersDetailsTOEmployees
(
   @EmployeeId int,
   @JobId int
)
AS
BEGIN
select ORSGroup6.JobseekersPersonalDetails.FirstName,
ORSGroup6.JobseekersPersonalDetails.LastName,
ORSGroup6.JobseekersPersonalDetails.ContactNo,
ORSGroup6.JobseekersPersonalDetails.EmailAddress,
ORSGroup6.JobSeekerProfessionalDetails.CurrentDesignation,
ORSGroup6.JobSeekerProfessionalDetails.PrimarySkills,
ORSGroup6.JobSeekerProfessionalDetails.SecondarySkills,
ORSGroup6.JobSeekerProfessionalDetails.TrainingAttended,
ORSGroup6.JobSeekerProfessionalDetails.Designation,
ORSGroup6.JobSeekerProfessionalDetails.Location,
ORSGroup6.JobSeekerProfessionalDetails.Experience
From ORSGroup6.AppliedJobs LEFT OUTER JOIN ORSGroup6.JobDetails on ORSGroup6.JobDetails.JobId=ORSGroup6.AppliedJobs.JobId
LEFT OUTER JOIN ORSGroup6.JobSeekerProfessionalDetails On ORSGroup6.JobSeekerProfessionalDetails.JobSeekerID=ORSGroup6.AppliedJobs.JobSeekerID
LEFT OUTER JOIN ORSGroup6.JobseekersPersonalDetails on ORSGroup6.JobseekersPersonalDetails.JobSeekerID=ORSGroup6.AppliedJobs.JobSeekerID
Where ORSGroup6.AppliedJobs.JobId=@JobId AND ORSGroup6.AppliedJobs.EmployeeId=@EmployeeId
END


--Procedure to View Applied Job Details

Alter Procedure ORSGroup6.ViewAppliedJobs
(
@JobSeekerId int
)
AS
BEGIN 
select [CompanyName],[Post],[Vacancies],[PostedDate],[LastDate],[CompanyDescription],[Package],[JobLocation],[Experience] from [ORSGroup6].[JobDetails]
Where [JobId]=ANY((select [JobId] from [ORSGroup6].[AppliedJobs] where [ORSGroup6].[AppliedJobs].JobSeekerId=@JobSeekerId))
END 

Exec ORSGroup6.ViewAppliedJobs 1;

select * from ORSGroup6.AppliedJobs;

select * from ORSGroup6.JobDetails;

--Procedure to search jobs based on Location

Alter PROCEDURE ORSGroup6.SearchbyLocation
( @JobLocation varchar(30) )
AS 
BEGIN
 SELECT * from ORSGroup6.JobDetails where JobDetails.JobLocation=@JobLocation
END

exec  ORSGroup6.SearchbyLocation 'Pune';

--Procedure to search jobs based on Designation

Alter PROCEDURE ORSGroup6.SearchbyDesignation
( @Designation varchar(20) )
AS 
BEGIN
 SELECT * from  ORSGroup6.JobDetails where  ORSGroup6.JobDetails.Post=@Designation;
END

exec ORSGroup6.SearchbyDesignation 'Software Analyst'

--Procedure to search jobs based on Experience

Alter PROCEDURE ORSGroup6.SearchbyExperience
( @Experience varchar(20) )
AS 
BEGIN
 SELECT * from  ORSGroup6.JobDetails where  ORSGroup6.JobDetails.Experience=@Experience;
END



